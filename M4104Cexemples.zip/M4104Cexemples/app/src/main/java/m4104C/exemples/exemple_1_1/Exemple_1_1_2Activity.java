package m4104C.exemples.exemple_1_1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import m4104C.exemples.R;

public class Exemple_1_1_2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // On charge le XML pour créer l'UI
        setContentView(R.layout.activity_exemple_1_1_2);
    }
}
